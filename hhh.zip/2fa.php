
<!DOCTYPE html>
  <html lang="en">
  <head>  
  <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="shortcut icon" href="img.jpg" type="image/x-icon">
      <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/live2d.css">
      <link rel="stylesheet" href="assets/css/menu.css">
      <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
      <link rel="stylesheet" href="https://unicons.iconscout.com/release/v3.0.6/css/line.css">
<title>Web lấy mã 2fa</title>
<center><h1><form method = “post” action = 2fa.php?>
<br>
<br>
<br>
<br>
<br>
<body class="Border" onLoad="onCreate()">               
    <nav class="sidebar close">
        <header>
            <div class="image-text">
                <span class="image">
                    <img src="img.jpg">
                </span>

                <div class="text logo-text">
                    <span class="name">Nguyễn Phương Hưng</span>
                    <span class="profession">My Profile Site</span>
                </div>
            </div>

            <i class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div class="menu">

                <ul class="menu-links">
                    <li class="nav-link">
                        <a href="index.html">
                            <i class='bx bx-home-alt icon' ></i>
                            <span class="text nav-text">Home</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="diendan.html">
                            <i class='bx bx-chat icon' ></i>
                            <span class="text nav-text">Diễn Đàn</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="2fa.php">
                            <i class='bx bx bxl-facebook icon' ></i>
                            <span class="text nav-text">Get 2FA Facebook</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="short.php">
                            <i class='bx bx-link icon'></i>
                            <span class="text nav-text">Short Link</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="#">
                            <i class='bx bx-heart icon' ></i>
                            <span class="text nav-text">Likes</span>
                        </a>
                    </li>


                </ul>
            </div>

            <div class="bottom-content">
                </li>
                
            </div>
        </div>

    </nav>
<div class="row">
    <div class="container">
       
          
<textarea type="“text”" giữ="" chỗ="" name="key" style="border-radius: 15px 50px 30px; padding: 20px; margin: 0px; width: 914px; height: 77px;" placeholder="Nhập Mã 2 FA : BK5VTVQ7D2RB... "></textarea>
<br>
<center class="profile__buttons"><button type =“submit” class="button">Get Mã 2FA</button></center>
</form></center></h1>

<title>Mã 2FA Của Bạn Đây</title>
<br>

<center><h1> Mã 2 FA : <?php 

require_once 'GoogleAuthenticator.php';

if (isset($_GET['key']))
{
	$key = trim($_GET['key']);
	$ga = new PHPGangsta_GoogleAuthenticator();
	$code = $ga->getCode($key);
	$list = [
	"key"=>$key,
	"code"=>$code
	];
	$daucatmoi = json_encode($list, JSON_PRETTY_PRINT);
	$memay = json_decode($daucatmoi, true);
	echo $memay['code'];
}
?></h1></center>
<script>
  function add_logs(txt) {
    $("#output").val($("#output").val() + '\n' + txt);
  }
  function clean_logs() {
    $("#output").val('')
  }
  $(document).ready(function () {
    $("#submit").click(function () {
      clean_logs();
      var tokens = $.trim($("#listToken").val()).split('\n');
      $.each(tokens, function (idx, token) {
        var cur_tokens = token.split('|');
        var last_idx = cur_tokens.length - 1;
        $.get('/tok/' + cur_tokens[last_idx].replace(/\ /g, '')).done(function (data) {
          add_logs(token + '|' + data.token);
        });
      });
    });

    $("#copy_btn").click(function () {
      $("#output").select();
      document.execCommand('copy');
    });

    $.ajax({
      'type': 'GET',
      'url': "/ip",
      success: function (response) {
          if (response.data.country === 'VN') {
            $("#ads_row").hide();
            $("#ads_th").hide();
          }
          if (response.data.country === 'TH') {
            $("#ads_row").hide();
          } else {
            $("#ads_th").hide();
          }
      },
      error: function (error) {
      }
      })
  });
</script>
             <footer class="footer container">
                  <span class="footer__copy">
                      &#169; <a href=""></a> Code by Nguyễn Phương Hưng
                  </span>
              </footer>
    </section>




    
      <script src="assets/js/scrollreveal min.js"></script>
      <script src="assets/js/main.js"></script>
          <script src="https://cdn.jsdelivr.net/gh/CDNSFree2/heartclick.js@main/heartclick.js"></script>  
<script>
   $(window).on("load",function ( ){
     $(."loader-wrapper").fadeOut("slow");
});
</script>
<script src="assets/js/menu.js"></script>
 
<audio autoplay>

  <source src="assets/audio/vol2.mp3" type="audio/mpeg">

</audio>
<script src="assets/js/script.js"></script>
</html>
