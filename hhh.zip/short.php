
<!DOCTYPE html>
  <html lang="en">
  <head>  
  <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="shortcut icon" href="img.jpg" type="image/x-icon">
      <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/live2d.css">
      <link rel="stylesheet" href="assets/css/menu.css">
      <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
      <link rel="stylesheet" href="https://unicons.iconscout.com/release/v3.0.6/css/line.css">
    <meta property="fb:app_id" content="423128345080344" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
<br>
<br>
<br>
<br>
<br>
<body class="Border" onLoad="onCreate()">               
    <nav class="sidebar close">
        <header>
            <div class="image-text">
                <span class="image">
                    <img src="img.jpg">
                </span>

                <div class="text logo-text">
                    <span class="name">Nguyễn Phương Hưng</span>
                    <span class="profession">My Profile Site</span>
                </div>
            </div>

            <i class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div class="menu">

                <ul class="menu-links">
                    <li class="nav-link">
                        <a href="index.html">
                            <i class='bx bx-home-alt icon' ></i>
                            <span class="text nav-text">Home</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="diendan.html">
                            <i class='bx bx-chat icon' ></i>
                            <span class="text nav-text">Diễn Đàn</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="2fa.php">
                            <i class='bx bx bxl-facebook icon' ></i>
                            <span class="text nav-text">Get 2FA Facebook</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="short.php">
                            <i class='bx bx-link icon'></i>
                            <span class="text nav-text">Short Link</span>
                        </a>
                    </li>

                    <li class="nav-link">
                        <a href="#">
                            <i class='bx bx-heart icon' ></i>
                            <span class="text nav-text">Likes</span>
                        </a>
                    </li>


                </ul>
            </div>

            <div class="bottom-content">
                </li>
                
            </div>
        </div>

    </nav>
<div class="container">
    <br>
    <div class="card">
  <div class="card-header">
  </div>
  <div class="card-body">
    
  <div class="md-form">
    <div class="col-md-12 mb-12">
      <input type="text" class="form-control" name="linkcanrutgon" id="linkcanrutgon" style="border-radius: 15px 50px 30px; padding: 20px; margin: 0px; width: 914px; height: 77px;" placeholder="Điền link cần rút gọn"
        required>
    </div>
  </div>
  <br>
  <br>
    <div class="md-form" id="ketqua">
      <div class="col-md-12 mb-12">
  <input id="messagess" type="text" style="border-radius: 15px 50px 30px; padding: 20px; margin: 0px; width: 914px; height: 77px;" placeholder="Link sau khi rút gọn sẽ hiển thị ở đây" class="form-control" readonly>
</div></div><center>
     <div class="md-form">
    <div class="col-md-12 mb-12">
        <br>
        <br>
        <center class="profile__buttons">
 <button onclick ="rutgon()" id="submit" class="button">Rút gọn link</button><button id="copy" onclick="copy()" class="button">Copy link</button></center>
</div></div>

</center>

<center>
   
</center>
  </div>
</div>

</div>


     <!-- Start your project here-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <script>
function rutgon(){
$('#submit').prop('disabled', true);
$("#submit").text("Vui lòng chờ...");
document.getElementById("copy").style.display = "none";
document.getElementById("ketqua").style.display = "none";
var link=$("#linkcanrutgon").val();
        $.ajax({
            type: "POST",
            url: "nhan_rutgon.php",
            data: {action:'rutgon',link:link},
            dataType: "JSON",
             success: function(data) {
             $("#messagess").val(data);
             $('#submit').prop('disabled', false);
             $("#submit").text("Rút gọn link");
             $("#linkcanrutgon").val("");
             document.getElementById("copy").style.display = "-webkit-inline-box";
             document.getElementById("ketqua").style.display = "block";
            //$("#messagess").addClass("alert alert-success");
            },
            error: function(err) {
            $("#messagess").val(data);
            //$("#messagess").addClass("alert alert-danger");
            }
        });
}
  </script>
  <script>
  function copy() {
  var copyText = document.getElementById("messagess");
  copyText.select();
  document.execCommand("copy");
  alert("Đã copy link rút gọn.");
}
  </script>
               <footer class="footer container">
                  <span class="footer__copy">
                      &#169; <a href=""></a> Code by Nguyễn Phương Hưng
                  </span>
              </footer>
      <script src="assets/js/scrollreveal min.js"></script>
      <script src="assets/js/main.js"></script>
          <script src="https://cdn.jsdelivr.net/gh/CDNSFree2/heartclick.js@main/heartclick.js"></script>  
<script>
   $(window).on("load",function ( ){
     $(."loader-wrapper").fadeOut("slow");
});
</script>
<script src="assets/js/menu.js"></script>
 
<audio autoplay>

  <source src="assets/audio/vol2.mp3" type="audio/mpeg">

</audio>
<script src="assets/js/script.js"></script>
</html>
