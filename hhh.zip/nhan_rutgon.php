<?php
// Code By Võ Hữu Nhân
// https://www.facebook.com/Blackspy.IT
header('Content-Type: text/html; charset=UTF-8');
if($_POST['action'] == 'rutgon') {
if(!empty($_POST['link'])) {
$link=$_POST['link'];
$token = "08afb562b4fa6c4329c459aac20440ab43a1d067";
$ketqua = "https://api-ssl.bitly.com/v3/shorten?access_token=$token&longUrl=https://www.facebook.com/l.php?u=$link";
$content = file_get_contents($ketqua);
$json = json_decode($content, true);
$object = json_decode($content);
if(strpos($link, 'bit.ly') !== false){
$link = "Không thể rút gọn link đã qua rút gọn !";
} 
elseif(strpos($link, 'view-source') !== false){
$link = "Không chấp nhận các link có chứa mã nguồn Website";
}
elseif(filter_var($link, FILTER_VALIDATE_URL) === FALSE){
$link = "Đây không phải là link, vui lòng nhập link có chứa HTTP/s";
}
else {
$link = $object->data->url;}
echo json_encode($link);
}
else { echo json_encode("Chưa nhập gì làm sao mà rút gọn, cần viết code vui lòng liên hệ Blackspy (Võ Hữu Nhân) để thuê nhá ! : https://www.facebook.com/Blackspy.IT"); }
}
?>